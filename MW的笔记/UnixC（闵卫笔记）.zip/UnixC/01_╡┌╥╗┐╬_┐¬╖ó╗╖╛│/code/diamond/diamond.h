#ifndef _DIAMOND_H
#define _DIAMOND_H

void diamond (int h, int d, int s, char c);

#endif // _DIAMOND_H
