#include "predef.h"

int main (void) {
	print ();
	return 0;
}
