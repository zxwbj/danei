#include <iostream>
using namespace std;

int main (void) {
	cout << "Hello, C++ !" << endl;
	return 0;
}
