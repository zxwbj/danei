#ifndef _CALC_H
#define _CALC_H

int add (int a, int b);
int sub (int a, int b);

#endif // _CALC_H
