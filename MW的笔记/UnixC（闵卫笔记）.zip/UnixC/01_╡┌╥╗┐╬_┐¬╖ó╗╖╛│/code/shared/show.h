#ifndef _SHOW_H
#define _SHOW_H

void show (int a, char op, int b, int c);	

#endif // _SHOW_H
