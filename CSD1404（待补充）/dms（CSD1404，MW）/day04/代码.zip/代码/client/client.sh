#!/bin/bash
cd /home/tarena/mw/dms/client
./client
exit 0
