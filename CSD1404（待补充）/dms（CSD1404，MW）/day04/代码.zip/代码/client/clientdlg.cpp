#include <QtGui>
#include "clientdlg.h"
ClientDlg::ClientDlg (void) {
	QTextCodec::setCodecForTr (
		QTextCodec::codecForName ("utf-8"));
	setWindowTitle (QObject::tr (
		"DMS数据采集客户机", "utf-8"));
	resize (520, 520);
	m_browser = new QTextBrowser (this);
	QPushButton* btnStart = new QPushButton (
		QObject::tr ("开始", "utf-8"), this);
	connect (btnStart, SIGNAL (clicked ()),
		this, SLOT (onStart ()));
	QPushButton* btnClose = new QPushButton (
		QObject::tr ("关闭", "utf-8"), this);
	connect (btnClose, SIGNAL (clicked ()),
		this, SLOT (close ()));
	QHBoxLayout* layHor = new QHBoxLayout;
	layHor->addStretch ();
	layHor->addWidget (btnStart);
	layHor->addWidget (btnClose);
	layHor->addStretch ();
	QVBoxLayout* layVer = new QVBoxLayout;
	layVer->addWidget (m_browser);
	layVer->addLayout (layHor);
	setLayout (layVer);
	connect (&m_work, SIGNAL (update (QString)),
		this, SLOT (onUpdate (QString)));
}
void ClientDlg::onStart (void) {
	m_work.start ();
}
void ClientDlg::onUpdate (QString text) {
	m_browser->append (text);
}
